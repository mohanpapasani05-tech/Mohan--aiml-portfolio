Papasani Venkata Mohan - Personal Portfolio

Open mohan_portfolio.html in a browser. Certificate images are embedded in the HTML file, so no extra image files are required.
